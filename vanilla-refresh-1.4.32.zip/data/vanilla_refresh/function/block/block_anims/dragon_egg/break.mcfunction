
kill @s[type=marker]