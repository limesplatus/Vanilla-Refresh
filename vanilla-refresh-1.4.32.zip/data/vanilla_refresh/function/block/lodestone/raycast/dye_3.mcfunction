scoreboard players add temp refresh_count 1

particle dust{color:[1.0, 0.882, 0.0],scale:1.25} ~ ~ ~ 0 0 0 0 1 force @p[tag=refresh_temp_pearlholder]



particle electric_spark ~ ~ ~ 0 0 0 0 1 force @p[tag=refresh_temp_pearlholder]
execute unless score temp refresh_count matches 16.. positioned ^ ^ ^1 run function vanilla_refresh:block/lodestone/raycast/dye_3
scoreboard players reset temp refresh_count